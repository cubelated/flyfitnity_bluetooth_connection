#!/usr/bin/python3

"""Copyright (c) 2019, Douglas Otwell

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import dbus

from advertisement import Advertisement
from service import Application, Service, Characteristic, Descriptor
import signal                   
import sys
import RPi.GPIO as GPIO
import threading

GATT_CHRC_IFACE = "org.bluez.GattCharacteristic1"
NOTIFY_TIMEOUT = 500
BUTTON_GPIO = 14
    
class BikeAdvertisement(Advertisement):
    def __init__(self, index):
        Advertisement.__init__(self, index, "peripheral")
        self.add_local_name("Fitness Bike")
        self.include_tx_power = True

class BikeService(Service):
    BIKE_UUID = "00000000-6a70-11ed-a1eb-0242ac120002"
    detect = False
    
    def signal_handler(sig, frame):
        GPIO.cleanup()
        sys.exit(0)

    def button_callback(self, cycle):
        
        cycle = cycle + 1
        self.set_cycle(cycle)
        print("Cycles: ", cycle)
        
    def setup_gpio(self):
        print('SETUP GPIO')
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(BUTTON_GPIO, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            
        GPIO.add_event_detect(BUTTON_GPIO, GPIO.RISING, callback=lambda x: self.button_callback(self.get_cycle()), bouncetime=250)
            
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.pause()

    def __init__(self, index):
        self.cycle = 0

        Service.__init__(self, index, self.BIKE_UUID, True)
        self.add_characteristic(CycleCharacteristic(self))
        
        t1 = threading.Thread(target=self.setup_gpio)
        t1.start()
        
    def get_cycle(self):
        return self.cycle

    def set_cycle(self, cycle):
        self.cycle = cycle


class CycleCharacteristic(Characteristic):
    CYCLE_CHARACTERISTIC_UUID = "00000001-6a70-11ed-a1eb-0242ac120002"
    
    def __init__(self, service):
        self.notifying = False

        Characteristic.__init__(
                self, self.CYCLE_CHARACTERISTIC_UUID,
                ["notify", "read"], service)
        self.add_descriptor(CycleDescriptor(self))

    def get_cycle(self):
        value = []
        cycle = self.service.get_cycle()
        
        print('Get Cycles: ', cycle);
        
        strtemp = str(cycle)
        
        for c in strtemp:
            value.append(dbus.Byte(c.encode()))
        
        return value

    def set_cycle_callback(self):
        if self.notifying:
            value = self.get_cycle()
            print('Notify: ', value)
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])

        return self.notifying

    def StartNotify(self):
        if self.notifying:
            return
        
        self.service.set_cycle(0)
        print('enable notify')
        self.notifying = True

        value = self.get_cycle()
        self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
        self.add_timeout(NOTIFY_TIMEOUT, self.set_cycle_callback)

    def StopNotify(self):
        self.notifying = False
        #self.set_cycle(0)
        print('stop notify')
        
    def ReadValue(self, options):
        print('read data')
        value = self.get_cycle()
        
        return value
        

class CycleDescriptor(Descriptor):
    CYCLE_DESCRIPTOR_UUID = "2901"
    CYCLE_DESCRIPTOR_VALUE = "Number of Cycles"

    def __init__(self, characteristic):
        Descriptor.__init__(
                self, self.CYCLE_DESCRIPTOR_UUID,
                ["read"],
                characteristic)

    def ReadValue(self, options):
        value = []
        desc = self.CYCLE_DESCRIPTOR_VALUE

        for c in desc:
            value.append(dbus.Byte(c.encode()))

        return value
    

app = Application()
app.add_service(BikeService(0))
app.register()

adv = BikeAdvertisement(0)
adv.register()  

try:
    app.run()
except KeyboardInterrupt:
    app.quit()
